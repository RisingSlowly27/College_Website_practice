export default function Index() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-100 to-slate-200 p-6">
      <div className="relative w-full max-w-[369px] rounded-tl-[46%] bg-white shadow-[0_4px_23px_0_rgba(0,0,0,0.16)]">
        <div className="relative mx-auto aspect-square w-[87%] pt-[8%]">
          <div className="absolute inset-0 translate-x-2 translate-y-2 rounded-tl-[48%] rounded-br-[62%] bg-gradient-to-b from-brand to-neutral-900 shadow-[0_2px_4px_0_rgba(0,0,0,0.25)]" />
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/b93ec1a196616a46403cd210250006b2234f15cf?width=624"
            alt="Ashish Kumar Layek"
            className="absolute inset-0 h-full w-full rounded-tl-[48%] rounded-br-[62%] object-cover shadow-[0_2px_4px_0_rgba(0,0,0,0.15)]"
          />
        </div>

        <div className="px-8 pb-8 pt-6 text-center">
          <h1 className="text-2xl font-bold text-brand sm:text-3xl">
            Ashish Kumar Layek
          </h1>
          <p className="mt-1 text-sm font-medium text-brand sm:text-base">
            Assistant Professor
          </p>
          <p className="mt-4 text-sm font-light leading-relaxed text-black">
            Computer Science and Technology
            <br />
            Mail: ashish@cs.iiests.ac.in
            <br />
            Ext: 000000-000
          </p>
        </div>
      </div>
    </div>
  );
}
